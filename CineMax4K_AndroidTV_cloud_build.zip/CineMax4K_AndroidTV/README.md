# CineMax 4K — Android TV starter

Starter técnico em Kotlin para Android TV. Inclui interface escura, elementos focáveis para navegação por controle remoto, catálogo demonstrativo, favoritos e base de reprodução usando AndroidX Media3 / ExoPlayer.

## Abrir no Android Studio
1. Extraia o ZIP.
2. Abra a pasta `CineMax4K_AndroidTV` no Android Studio atualizado.
3. Aguarde a sincronização do Gradle.
4. Execute em um emulador Android TV ou dispositivo compatível.

## Reprodução de conteúdo
O catálogo é demonstrativo e não contém filmes completos. Em `MainActivity.kt`, atribua `streamUrl` a uma URL HTTPS de vídeo que você possua ou esteja licenciado para distribuir. Para conteúdo comercial real, o fornecedor pode exigir autenticação, tokens, DRM (por exemplo Widevine), licença de reprodução e integração de catálogo. Não coloque chaves secretas no aplicativo.

## 4K e qualidade
A dependência Media3/ExoPlayer fornece a base do player, mas não garante 4K automaticamente. A resolução real depende do arquivo/manifesto, codec, DRM, dispositivo, tela e banda. Um serviço comercial pode exigir HLS/DASH adaptativo, Widevine e pipeline de transcodificação.

## Sem anúncios e gratuito
Este starter não integra SDK de anúncios. Ele não inclui backend, catálogo comercial, login, pagamentos, DRM, hospedagem ou licenças. Esses componentes precisam ser definidos e implementados antes de uma distribuição pública.

## Próximas etapas recomendadas
- Criar backend de catálogo e autenticação.
- Integrar fornecedor autorizado de conteúdo e DRM.
- Melhorar navegação por foco, imagens de capa e acessibilidade.
- Adicionar histórico e continuar assistindo.
- Testar em TVs reais e validar decodificação 4K.
