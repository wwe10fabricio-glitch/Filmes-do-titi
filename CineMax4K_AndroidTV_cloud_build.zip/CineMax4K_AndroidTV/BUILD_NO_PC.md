# Gerar o APK usando apenas o celular

Este projeto inclui um fluxo de compilação na nuvem via GitHub Actions. Você precisa de uma conta GitHub e internet; não precisa instalar Android Studio nem extrair o projeto no celular.

1. No navegador do celular, entre em https://github.com/new e crie um repositório vazio chamado `CineMax4K-AndroidTV`.
2. No repositório, use **Add file → Upload files** e envie o conteúdo do ZIP do projeto. Se o navegador não permitir enviar uma pasta inteira, será necessário usar a opção de upload de arquivos múltiplos ou um serviço de edição de repositório pelo navegador.
3. Faça commit dos arquivos na branch `main`.
4. Abra a aba **Actions**, selecione **Build CineMax 4K APK** e toque em **Run workflow** (ou aguarde a compilação automática após o commit).
5. Quando terminar, abra a execução concluída e baixe o artefato `CineMax4K-AndroidTV-debug-apk`. O GitHub baixa um ZIP com o APK dentro; isso é um pacote de artefato do GitHub, não o código-fonte.
6. Para instalar na TV, transfira o APK para ela e permita a instalação de apps dessa origem, se o Android TV solicitar.

Observações:
- Este fluxo produz um APK de depuração, não um APK assinado para publicação na Play Store.
- A compilação pode precisar de ajustes caso dependências ou configuração do projeto mudem.
- O APK atual é um protótipo. Ele não inclui catálogo comercial, contas de streaming, URLs reais de filmes ou acordos de licenciamento. Não promete reprodução 4K sem uma fonte compatível, dispositivo e rede adequados.
