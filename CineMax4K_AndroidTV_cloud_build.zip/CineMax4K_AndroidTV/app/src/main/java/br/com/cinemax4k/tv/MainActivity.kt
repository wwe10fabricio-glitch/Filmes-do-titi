package br.com.cinemax4k.tv

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private const val BG = 0xFF080B11.toInt()
private const val PANEL = 0xFF171D28.toInt()
private const val RED = 0xFFFF1744.toInt()
private const val WHITE = 0xFFF7F8FC.toInt()
private const val MUTED = 0xFFADB6C7.toInt()

data class Movie(
    val title: String,
    val kind: String,
    val year: String,
    val description: String,
    // Replace only with a stream URL you own or are licensed to distribute.
    val streamUrl: String? = null
)

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var player: ExoPlayer? = null
    private val movies = listOf(
        Movie("Viagem às Estrelas", "Ficção científica", "2025", "Uma aventura espacial original sobre descoberta e os mistérios do universo."),
        Movie("O Último Horizonte", "Drama", "2025", "Uma comunidade precisa recomeçar quando o mundo ao redor muda."),
        Movie("Cidade em Movimento", "Ação", "2024", "Uma história de ação fictícia pelas ruas de uma metrópole."),
        Movie("Mundos de Papel", "Animação", "2025", "Uma jornada colorida em que a imaginação transforma tudo."),
        Movie("Planeta Azul", "Documentário", "2024", "Paisagens naturais e ecossistemas extraordinários."),
        Movie("Além das Montanhas", "Aventura", "2023", "Uma expedição põe à prova a amizade e a determinação.")
    )
    private val favorites = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildHome()
    }

    private fun label(text: String, size: Float, color: Int = WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun button(text: String, action: () -> Unit): TextView =
        label(text, 18f, WHITE, true).apply {
            setPadding(22, 14, 22, 14)
            setBackgroundColor(PANEL)
            isFocusable = true
            isFocusableInTouchMode = true
            setOnFocusChangeListener { v, focused ->
                v.setBackgroundColor(if (focused) RED else PANEL)
                v.scaleX = if (focused) 1.04f else 1f
                v.scaleY = if (focused) 1.04f else 1f
            }
            setOnClickListener { action() }
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(0, 0, 12, 12)
            layoutParams = params
        }

    private fun buildHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 24, 36, 24)
            setBackgroundColor(BG)
        }
        root.addView(label("▶ CineMax 4K", 30f, RED, true))
        root.addView(label("FILMES E SÉRIES · SEM ANÚNCIOS", 14f, MUTED, true))
        root.addView(label("Cinema em outro nível.", 34f, WHITE, true))
        root.addView(label("Escolha um título usando as setas e OK do controle remoto.", 17f, MUTED))

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        nav.addView(button("Início") { buildHome() })
        nav.addView(button("Filmes") { showCatalog(movies.filter { it.kind != "Animação" }) })
        nav.addView(button("Séries") { showCatalog(movies.filter { it.title == "O Último Horizonte" || it.title == "Planeta Azul" }) })
        nav.addView(button("Minha lista") { showCatalog(movies.filter { favorites.contains(it.title) }) })
        root.addView(nav)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 20)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        content.addView(label("Em destaque", 24f, WHITE, true))
        content.addView(label("Catálogo de demonstração — adicione seus títulos licenciados no código.", 15f, MUTED))
        showCatalog(movies, false)
        setContentView(root)
        // Start keyboard/remote focus on the first interactive item.
        nav.getChildAt(0).requestFocus()
    }

    private fun showCatalog(items: List<Movie>, rebuild: Boolean = true) {
        if (rebuild) {
            root.removeAllViews()
            root.addView(label("▶ CineMax 4K", 30f, RED, true))
            root.addView(button("← Voltar ao início") { buildHome() })
            val scroll = ScrollView(this)
            content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 18, 0, 24)
            }
            scroll.addView(content)
            root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        content.removeAllViews()
        if (items.isEmpty()) {
            content.addView(label("Sua lista está vazia.", 22f, MUTED))
            return
        }
        items.forEach { movie ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(16, 12, 16, 12)
                setBackgroundColor(PANEL)
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label(movie.title, 22f, WHITE, true))
            info.addView(label("${movie.year} · ${movie.kind} · preparado para 4K*", 14f, MUTED))
            info.addView(label(movie.description, 14f, MUTED))
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(button("▶ Assistir") { play(movie) })
            row.addView(button(if (favorites.contains(movie.title)) "♥ Salvo" else "＋ Lista") {
                if (!favorites.add(movie.title)) favorites.remove(movie.title)
                showCatalog(items)
            })
            row.isFocusable = true
            row.setBackgroundColor(PANEL)
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 0, 0, 10)
            content.addView(row, params)
        }
        content.addView(label("*A reprodução 4K depende do vídeo licenciado, dispositivo, codec e conexão.", 13f, MUTED))
    }

    private fun play(movie: Movie) {
        val url = movie.streamUrl
        if (url.isNullOrBlank()) {
            android.app.AlertDialog.Builder(this)
                .setTitle(movie.title)
                .setMessage("Este título é demonstrativo. Para ativar a reprodução, configure uma URL HTTPS de vídeo que você tenha direito de distribuir.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        val playerView = PlayerView(this)
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(Uri.parse(url)))
            exo.prepare()
            exo.playWhenReady = true
        }
        setContentView(playerView)
        playerView.isFocusable = true
        playerView.requestFocus()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && player != null) {
            player?.release()
            player = null
            buildHome()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
